# Force Screen Update

WARNING:
	This function causes a ***significant*** power drain, please minimize use

`forceScreenUpdate` repaints the entire screen.
