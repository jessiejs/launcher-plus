# Add Text

`addText` takes one argument which is the text to display.
