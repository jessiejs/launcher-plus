# System Get Metadata

`sysGetMetadata` does the same thing as `playdate.system.getMetadata`
