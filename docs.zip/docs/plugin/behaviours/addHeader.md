# Add Header

`addHeader` adds a header with the text passed in the only argument
