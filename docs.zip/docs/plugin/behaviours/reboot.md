# Reboot

Reboots the device.
