# Get Dark Mode Manager

`getDarkModeManager` constructs a DarkModeManager, which has a getDarkModeEnabled function which returns a boolean, and a setDarkMode function which takes a boolean.
