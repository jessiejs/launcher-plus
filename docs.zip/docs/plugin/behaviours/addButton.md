# Add Button

`addButton` takes two arguments, the button text and the callback to run when the button is pressed.
