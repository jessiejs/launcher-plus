# Switch State

`switchState` takes in a state name and state options, for example, if your app has a "fileBrowser" state, you would do

```lua
switchState("fileBrowser",{
	path="/System/"
})
```
