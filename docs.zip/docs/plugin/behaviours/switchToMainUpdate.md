# Switch to Main Update

Switches `playdate.update` to be the primary ui renderer.
