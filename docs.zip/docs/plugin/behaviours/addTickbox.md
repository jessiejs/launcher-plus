# Add Tickbox

`addTickbox` takes 3 arguments, the text, the value getter, and the value setter.
