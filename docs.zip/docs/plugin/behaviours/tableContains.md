# Table Contains

`tableContains` checks if a table contains a value. It takes two arguments, the table to search and the object to search for.
