# Allocate

`allocate` allocates a ui section with the height passed in the only argument, it returns a UIAllocation, with a top property, a height property, and also a rect() function that returns the rectangle.
