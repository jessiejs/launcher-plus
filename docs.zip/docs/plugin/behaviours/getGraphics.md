# Get Graphics

`getGraphics` returns `playdate.graphics`
