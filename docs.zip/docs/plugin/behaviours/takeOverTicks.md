# Take over Ticks

`takeOverTicks` replaces `playdate.update` with the first argument
