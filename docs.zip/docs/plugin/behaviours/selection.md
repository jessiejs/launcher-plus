# Selection

`selection` adds a selection to the UI, it is not very user friendly, but it takes three arguments, the rect of the selection, the actions, and an optional corner radius.
