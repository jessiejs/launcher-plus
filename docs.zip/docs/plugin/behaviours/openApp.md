# Open App

`openApp` takes a string which is the path of a pdx to open.
